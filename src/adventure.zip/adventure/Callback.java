
package adventure;

/*
 * Interface Callback
 *
 * Used to register callbacks with the clock
 *
 */

public interface Callback {

  public void action ();

}
