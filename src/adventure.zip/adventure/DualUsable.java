package adventure;

public interface DualUsable {

   public String name ();
   public void use (Person user, MobileThing obj);

}
